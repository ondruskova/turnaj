﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turnaj
{
    internal class Player
    {
        public Player(string jmeno, int vek)
        {
            Jmeno = jmeno;
            Vek = vek;
        }

        public string Jmeno {  get; private set; }
        public int Vek { get; private set; }


    }
}
