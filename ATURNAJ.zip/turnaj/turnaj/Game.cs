﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turnaj
{
    internal class Game
    {
        public Game(Team t1, Team t2)
        {
            this.t1 = t1;
            this.t2 = t2;
        }

        public Team t1 {  get; private set; }
        public Team t2 { get; private set; }
        private static Random random = new Random();

        public void PlayGame()
        {
            int los = random.Next(0, 2);

            if(los == 0)
            {
                t1.HasWon = false;
            }
            else
            {
                t2.HasWon = false;
            }
        }
    }
}
