﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace turnaj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Player p1 = new Player("Pepa", 20);
            Player p2 = new Player("Hana", 30);
            Player p3 = new Player("Olda", 10);
            Player p4 = new Player("Jana", 50);
            Player p5 = new Player("Anna", 55);
            Player p6 = new Player("David", 56);
            Player p7 = new Player("Soběslav", 30);
            Player p8 = new Player("Martin", 11);

            Team t1 = new Team("T1");
            Team t2 = new Team("T2");
            Team t3 = new Team("T3");
            Team t4 = new Team("T4");

            t1.AddPlayer(p1);
            t1.AddPlayer(p2);
            t2.AddPlayer(p3);
            t2.AddPlayer(p4);
            t3.AddPlayer(p5);
            t3.AddPlayer(p6);
            t4.AddPlayer(p7);
            t4.AddPlayer(p8);

            Tournament turnaj = new Tournament("turnaj 1");

            turnaj.TeamList.Add(t1);
            turnaj.TeamList.Add(t2);
            turnaj.TeamList.Add(t3);
            turnaj.TeamList.Add(t4);

            bool pokracovani = true;
            while(pokracovani == true)
            {
                pokracovani = turnaj.CreateAndPlayGame();
            }
            Console.WriteLine(turnaj.GetWinner());
            
        }
    }
}
