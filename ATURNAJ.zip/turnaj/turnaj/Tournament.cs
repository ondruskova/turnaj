﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace turnaj
{
    internal class Tournament
    {
        public Tournament(string jmeno)
        {
            Jmeno = jmeno;
            GameList = new List<Game>();
            TeamList = new List<Team>();
        }

        public string Jmeno {  get; private set; }
        public List<Game> GameList { get; private set; }
        public List<Team> TeamList { get; private set; }

        public bool CreateAndPlayGame()
        {
            Team tym1 = null;
            Team tym2 = null;
            foreach(Team t1 in TeamList)
            {
                if(t1.HasWon == true)
                {
                    if(tym1 == null)
                    {
                        tym1 = t1;
                    }

                    else if (tym2 == null)
                    {
                        tym2 = t1;
                    }

                    if(tym1 != null && tym2 != null)
                    {
                        Game hra = new Game(tym1, tym2);
                        GameList.Add(hra);
                        hra.PlayGame();
                        return true;
                    }

                }
           }
            return false;
        }

        public string GetWinner()
        {
            int pocettymu = 0;
            Team vyherni = null;

            foreach(Team t1 in TeamList)
            {
                if(t1.HasWon == true)
                {
                    pocettymu++;
                    vyherni = t1;

                }

                if(pocettymu > 1)
                {
                    return "Turnaj neskončil.";
                }
            }

            return "Vyhrál: " + vyherni.Jmeno;
        }
    }
}
