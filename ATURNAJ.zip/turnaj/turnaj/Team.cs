﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turnaj
{
    internal class Team
    {
        public string Jmeno {  get; private set; }
        public List<Player> ListHracu {  get; private set; }
        public bool HasWon {  get; set; }

        public Team(string jmeno)
        {
            Jmeno = jmeno;
            ListHracu = new List<Player>();
            HasWon = true;
        }

        public void AddPlayer(Player p1)
        {
            if(ListHracu.Count < 2)
            {
                ListHracu.Add(p1);
            }
            else
            {
                Console.WriteLine("Nejde přidat více hráčů.");
            }
        }
    }
}
