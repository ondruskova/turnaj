﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace depo
{
    internal class Depo
    {
        List<Balik> seznamBaliku = new List<Balik>();

        public void pridejBalik(Balik balik)
        {
            seznamBaliku.Add(balik);
        }

        public string vypisInfoOVsechBalicich()
        {
            string vysledek = "";
            foreach (Balik item in seznamBaliku)
            {
                vysledek += item.VratInfo();
                vysledek += "\n";
            }
            return vysledek;  
        }

        public int vratNedorucene()
        {
            int x = 0;
            foreach (Balik item in seznamBaliku)
            {
                if(item.StavDoruceni == 2)
                {
                    x++;
                }
            }
            return x;
        }

        public int spocitejDorucene()
        {
            int x = 0;
            foreach(Balik item in seznamBaliku)
            {
                if (item.StavDoruceni == 1)
                {
                    x++;
                }
            }
            return x;
        }
        public int spocitejJesteNedorucovane()
        {
            int x = 0;
            foreach (Balik item in seznamBaliku)
            {
                if (item.StavDoruceni == 0)
                {
                    x++;
                }
            }
            return x;
        }
        public int spocitejDleZadani(int stav)
        {
            int x = 0;
            foreach (Balik item in seznamBaliku)
            {
                if (item.StavDoruceni == stav)
                {
                    x++;
                }
            }
            return x;
        }

        public void dorucJeden()
        {
            foreach (Balik item in seznamBaliku)
            {
                if(item.StavDoruceni == 0)
                {
                    item.Doruc();
                    break;
                }
            }
        }
    }
}
