﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace depo
{
    internal class Balik
    {
        public string JmenoPrijemce;
        public int CisloBaliku;
        public int Hmotnost;
        public int StavDoruceni { get; private set; } = 0;
        static Random r = new Random();

        public Balik(string jmenoPrijemce, int cisloBaliku)
        {
            JmenoPrijemce = jmenoPrijemce;
            CisloBaliku = cisloBaliku;

            Hmotnost = r.Next(1, 11);
            StavDoruceni = 0;
        }

        public string VratInfo()
        {
            string vypis;
            return vypis = "Jméno příjemce: " + JmenoPrijemce + "Číslo balíku: " + CisloBaliku + "Hmotnost: " + Hmotnost + "Stav doručení: " + prevedStav();
        }

        public string prevedStav()
        {
            if (StavDoruceni == 2)
            {
                return "Neúspěšně doručeno.";
            }
            else if (StavDoruceni == 1)
            {
                return "Doručeno úspěšně.";
            }
            else
            {
                return "Ještě nedoručeno";
            }
        }

        public void Doruc()
        {
            if (r.Next(1, 11) <= 7)
            {
                StavDoruceni = 1;
            }
            else
            {
                StavDoruceni = 2;
            }

        }
    }
}
